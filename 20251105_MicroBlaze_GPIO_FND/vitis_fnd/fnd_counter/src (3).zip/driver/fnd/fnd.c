/*
 * fnd.c
 *
 *  Created on: 2025. 11. 4.
 *      Author: kccistc
 */

#include "fnd.h"

enum {
	DIGIT_1, DIGIT_10, DIGIT_100, DIGIT_1000
};

hFnd fnd;
int fndNumber;	// fnd display data

void FND_Init() {
	fnd.gpio_seg = GPIOA;
	fnd.gpio_com = GPIOB;
	fnd.digit_1 = GPIO_PIN_0;
	fnd.digit_10 = GPIO_PIN_1;
	fnd.digit_100 = GPIO_PIN_2;
	fnd.digit_1000 = GPIO_PIN_3;

	fnd.gpio_seg->CR = 0xff;
	fnd.gpio_com->CR = 0xff;
}

void FND_SetNumber(int number) {
	fndNumber = number;
}

int FND_GetNumber() {
	return fndNumber;
}

void FND_DispNumber(/*int number*/) {
	static int fndPos = 0;	// 값을 기억한다.
	//fndNumber = number;

	fndPos = (fndPos + 1) % 4;

	FND_AllOff();

	switch (fndPos) {
	case DIGIT_1:
		FND_ShowDigit(fndNumber % 10);
		FND_SelDigit(fnd.digit_1);
		//usleep(100);
		break;

	case DIGIT_10:
		FND_ShowDigit(fndNumber / 10 % 10);
		FND_SelDigit(fnd.digit_10);
		//usleep(100);
		break;

	case DIGIT_100:
		FND_ShowDigit(fndNumber / 100 % 10);
		FND_SelDigit(fnd.digit_100);
		//usleep(100);
		break;

	case DIGIT_1000:
		FND_ShowDigit(fndNumber / 1000 % 10);
		FND_SelDigit(fnd.digit_1000);
		//usleep(100);
		break;
	}
}

void FND_AllOff() {
	GPIO_Set(fnd.gpio_com, fnd.digit_1);
	GPIO_Set(fnd.gpio_com, fnd.digit_10);
	GPIO_Set(fnd.gpio_com, fnd.digit_100);
	GPIO_Set(fnd.gpio_com, fnd.digit_1000);
}

void FND_SelDigit(int digit) {
	//fnd.gpio_com->ODR |= (0x0f << digit);	// 1로 바꾸어준다.
	//fnd.gpio_com->ODR &= ~(1 << digit);	// 0으로 바꾸어준다.

	GPIO_Reset(fnd.gpio_com, digit);		// 0으로 바꾸어준다.
}

void FND_ShowDigit(int digit) {
	uint8_t segFont[10] = { 0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8,
			0x80, 0x90 };
	GPIO_Write(fnd.gpio_seg, segFont[digit]);
}

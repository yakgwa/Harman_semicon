//#include <stdio.h>
//#include <stdint.h>
#include "xil_printf.h"
#include "xparameters.h"
#include "sleep.h"

#include "ap/ap.h"
#include "driver/common/millis.h"

/*
 typedef struct {
	volatile uint32_t CR;
	volatile uint32_t ODR;
	volatile uint32_t IDR;
} GPIO_TypeDef;
*/

/*
#define FND_SEG_BASEADDR XPAR_GPIO_0_S00_AXI_BASEADDR
#define FND_COM_BASEADDR XPAR_GPIO_1_S00_AXI_BASEADDR
#define BTN_BASEADDR	 XPAR_GPIO_2_S00_AXI_BASEADDR

#define FND_SEG		((GPIO_TypeDef *) FND_SEG_BASEADDR)
#define FND_COM		((GPIO_TypeDef *) FND_COM_BASEADDR)
#define BTN			((GPIO_TypeDef *) BTN_BASEADDR)
*/

int main() {
//
//	FND_SEG->CR = 0xff;	// output으로 설정하고 끄겠다?
//	FND_COM->CR = 0xff;	// output으로 설정하고 끄겠다?
//	BTN->CR = 0x00;		// output으로 설정하고 끄겠다?
//
	printf("hello world!\n");
	xil_printf("hello world!\n");

	ap_main();
//
//	FND_COM->ODR = 0x00;
//	while (1) {
//		//FND_SEG->ODR = 0xff;	// fnd 끔
//		FND_SEG->ODR = 0x00;	// fnd 켬
//		FND_COM->ODR = 0xf0;	// LED 켬 + fnd 0~3 자리수 켬
//		usleep(300000);
//
//		//FND_SEG->ODR = 0x00;	// fnd 켬
//		FND_SEG->ODR = 0xff;	// fnd 끔
//		FND_COM->ODR = 0x0f;	// LED 끔 + fnd 0~3 자리수 켬 // 00도 동일동작
//		usleep(300000);
//	}

	return 0;
}

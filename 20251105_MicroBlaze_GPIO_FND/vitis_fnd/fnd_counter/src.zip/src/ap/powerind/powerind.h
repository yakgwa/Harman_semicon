/*
 * powerind.h
 *
 *  Created on: 2025. 11. 5.
 *      Author: kccistc
 */

#ifndef SRC_AP_POWERIND_POWERIND_H_
#define SRC_AP_POWERIND_POWERIND_H_

#include "../../driver/led/led.h"
#include "../../driver/common/millis.h"
#include <stdint.h>

void initPowerInd();
void dispPowerInd();

#endif /* SRC_AP_POWERIND_POWERIND_H_ */
